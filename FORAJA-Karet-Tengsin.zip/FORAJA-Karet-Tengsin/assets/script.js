// EDIT NAMA PENGURUS, EMAIL, DAN DATA DIVISI DI FILE INI.
const leaders = [
  {role:"Ketua", name:"Nama Ketua", initials:"K", note:"Koordinator utama"},
  {role:"Wakil Ketua", name:"Nama Wakil Ketua", initials:"W", note:"Mendampingi ketua"},
  {role:"Sekretaris", name:"Nama Sekretaris", initials:"S", note:"Administrasi organisasi"},
  {role:"Bendahara", name:"Nama Bendahara", initials:"B", note:"Pengelolaan keuangan"}
];

const divisions = [
  {number:"01", name:"Perlindungan Anak Berkebutuhan Khusus", desc:"Mendorong lingkungan yang inklusif, setara, dan mendukung pemenuhan hak setiap anak.", lead:"Ketua Divisi: Nama Ketua", members:"Anggota: Nama Anggota 1 • Nama Anggota 2"},
  {number:"02", name:"Seni dan Budaya", desc:"Mengembangkan kreativitas, bakat, serta kecintaan terhadap seni dan budaya.", lead:"Ketua Divisi: Nama Ketua", members:"Anggota: Nama Anggota 1 • Nama Anggota 2"},
  {number:"03", name:"Publikasi dan Humas", desc:"Mengelola informasi, dokumentasi, publikasi kegiatan, dan komunikasi FORAJA.", lead:"Ketua Divisi: Nama Ketua", members:"Anggota: Nama Anggota 1 • Nama Anggota 2"},
  {number:"04", name:"Sarana dan Prasarana", desc:"Mendukung kebutuhan perlengkapan dan kesiapan fasilitas setiap kegiatan.", lead:"Ketua Divisi: Nama Ketua", members:"Anggota: Nama Anggota 1 • Nama Anggota 2"}
];

document.getElementById("teamGrid").innerHTML = leaders.map(person => `
  <article class="team-card">
    <div class="avatar">${person.initials}</div>
    <h3>${person.name}</h3><p>${person.role}</p><small>${person.note}</small>
  </article>`).join("");

document.getElementById("divisionGrid").innerHTML = divisions.map(item => `
  <article class="division-card">
    <div class="division-number">${item.number}</div>
    <div><h3>${item.name}</h3><p>${item.desc}</p><small>${item.lead}<br>${item.members}</small></div>
  </article>`).join("");

// Ganti alamat email contoh berikut dengan email resmi organisasi.
const officialEmail = "foraja.karettengsin@example.com";
const contactLink = document.getElementById("contactLink");
contactLink.href = `mailto:${officialEmail}`;
document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("navLinks").classList.toggle("open");
});
document.querySelectorAll("#navLinks a").forEach(link => link.addEventListener("click", () => {
  document.getElementById("navLinks").classList.remove("open");
}));

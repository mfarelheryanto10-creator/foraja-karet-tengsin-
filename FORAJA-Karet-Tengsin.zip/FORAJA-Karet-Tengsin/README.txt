FORAJA KARET TENGSIN — WEBSITE SIAP EDIT

ISI FOLDER
- index.html             Halaman utama website
- assets/style.css       Desain dan tampilan responsif
- assets/script.js       Data pengurus, divisi, email, dan navigasi

CARA MEMBUKA
1. Ekstrak ZIP ini.
2. Buka folder foraja-karet-tengsin.
3. Klik dua kali index.html untuk melihat website di browser.

CARA MENGUBAH NAMA PENGURUS DAN DIVISI
1. Buka assets/script.js dengan Notepad atau Visual Studio Code.
2. Ubah "Nama Ketua", "Nama Wakil Ketua", dan seterusnya dengan nama asli.
3. Ubah nama ketua dan anggota pada bagian divisions.
4. Simpan file, lalu refresh halaman website.

CARA MENGUBAH EMAIL
Di assets/script.js, ubah:
const officialEmail = "foraja.karettengsin@example.com";
menjadi alamat email resmi yang digunakan organisasi.

CARA PUBLIKASI GRATIS DENGAN GITHUB PAGES
1. Buat akun di github.com dan buat repository baru, misalnya foraja-karet-tengsin.
2. Upload index.html dan folder assets (jangan upload file ZIP saja).
3. Buka Settings > Pages.
4. Pada Build and deployment, pilih Deploy from a branch.
5. Pilih branch main dan folder /(root), lalu Save.
6. Tunggu proses selesai. Website akan tersedia di alamat GitHub Pages yang ditampilkan di halaman Pages.

CATATAN
- Nama, email, dan informasi organisasi di dalam website adalah contoh/placeholder; ganti sebelum dipublikasikan.
- Ini adalah website statis, tidak memiliki login admin atau database.
- Jangan memasukkan data pribadi anak seperti alamat rumah, nomor telepon pribadi, atau informasi sensitif ke halaman publik.
